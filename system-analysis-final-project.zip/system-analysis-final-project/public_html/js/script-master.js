document.getElementById('buyButton').addEventListener('click', function () {
    
    window.location.href = 'master-payment.html';
});

document.getElementById('viewMore').addEventListener('click', function () {
   
    window.location.href = 'master-view-more.html';
});

document.getElementById('back').addEventListener('click', function () {
    
    window.location.href = 'home.html';
});